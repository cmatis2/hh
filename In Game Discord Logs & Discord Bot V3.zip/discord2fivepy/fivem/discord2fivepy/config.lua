Config = {}

Config.ReviveEvent = 'esx_ambulancejob:revive' -- The event used to revive people (default: esx_ambulancejob:revive)
				
--Webhook settings
Config.Webhook = 'yourwebhookhere' -- Reports error messages in commands
Config.WebhookTitle = 'Liberty RP' -- Title for webhook
Config.WebhookFooter = 'made by Melktert' -- Footer of webhook
--Embed colors
Config.Success = 3145631 --
Config.Error = 16711680 -- https://www.mathsisfun.com/hexadecimal-decimal-colors.html (decimal colors)
Config.Neutral = 9606296 -- 
		
