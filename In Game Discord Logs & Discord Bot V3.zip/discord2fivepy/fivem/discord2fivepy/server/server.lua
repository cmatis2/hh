ESX = nil

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

AddEventHandler('onResourceStart', function(resourceName)
	if resourceName == 'discord2fivepy' then
		print('Discord2FivePY started')
		ReportToWebhook(Config.Neutral, Config.WebhookTitle, "Discord2FivePY by Melktert has been started", Config.WebhookFooter)
	end
end)



function ReportToWebhook(color, name, message, footer)
  local embed = {
        {
            ["color"] = color,
            ["title"] = "**".. name .."**",
            ["description"] = message,
            ["footer"] = {
            ["text"] = footer,
            },
        }
    }

  PerformHttpRequest(Config.Webhook, function(err, text, headers) end, 'POST', json.encode({username = name, embeds = embed}), { ['Content-Type'] = 'application/json' })
end

RegisterCommand('revivepy', function(source, args)
	if source == 0 then
		TriggerClientEvent(Config.ReviveEvent, args[1])
		ReportToWebhook(Config.Success, Config.WebhookTitle, "Successfully revived " .. GetPlayerName(args[1]), Config.WebhookFooter)
	end
end)

RegisterCommand('giveitempy', function(source, args, user)
	if source == 0 then
		local xPlayer = ESX.GetPlayerFromId(args[1])
		local item    = args[2]
		local count   = (args[3] == nil and 1 or tonumber(args[3]))

		if count ~= nil then
			if xPlayer.getInventoryItem(item) ~= nil then
				xPlayer.addInventoryItem(item, count)
				ReportToWebhook(Config.Success, Config.WebhookTitle, "Successfully gave " .. item .. " (" .. count .. ") to " .. xPlayer.getName(), Config.WebhookFooter)
			else
				ReportToWebhook(Config.Error, Config.WebhookTitle, "Invalid Item", Config.WebhookFooter)
			end
		else
			ReportToWebhook(Config.Error, Config.WebhookTitle, "Invalid Amount", Config.WebhookFooter)
		end
	end	
end)

RegisterCommand('setjobpy', function(source, args, user)
	if source == 0 then
		if tonumber(args[1]) and args[2] and tonumber(args[3]) then
			local xPlayer = ESX.GetPlayerFromId(args[1])

			if xPlayer then
				if ESX.DoesJobExist(args[2], args[3]) then
					xPlayer.setJob(args[2], args[3])
					ReportToWebhook(Config.Success, Config.WebhookTitle, "Successfully set job of " .. xPlayer.getName() .. " to " .. args[2] .. "(" .. args[3] .. ")", Config.WebhookFooter)
				else
					ReportToWebhook(Config.Error, Config.WebhookTitle, "Job does not exist", Config.WebhookFooter)
				end

			else
				ReportToWebhook(Config.Error, Config.WebhookTitle, "Player Not Online", Config.WebhookFooter)
			end
		else
			ReportToWebhook(Config.Error, Config.WebhookTitle, "Invalid Usage", Config.WebhookFooter)
		end
	end
end)

RegisterCommand('giveweaponpy', function(source, args, user)
	if source == 0 then
		local xPlayer    = ESX.GetPlayerFromId(args[1])
		local weaponName = string.upper(args[2])

		xPlayer.addWeapon(weaponName, tonumber(args[3]))
		ReportToWebhook(Config.Success, Config.WebhookTitle, "Successfully gave " .. weaponName .. " (" .. tonumber(args[3]) .. ") to " .. xPlayer.getName(), Config.WebhookFooter)
	end
end)

RegisterCommand('sendtopy', function(source, args, user)
	if source == 0 then
		local localPed = GetPlayerPed(args[1])
		SetEntityCoords(localPed, 221.29, -800.81, 30.7, true, false, false, true)
		ReportToWebhook(Config.Success, Config.WebhookTitle, "Successfully sent " .. GetPlayerName(args[1]) .. " to Legion Square Garage", Config.WebhookFooter)
	end
end)

RegisterCommand('giveaccountmoneypy', function(source, args, user)
	if source == 0 then
		local xPlayer = ESX.GetPlayerFromId(args[1])
		local account = args[2]
		local amount  = tonumber(args[3])

		if amount ~= nil then
			if xPlayer.getAccount(account) ~= nil then
				xPlayer.addAccountMoney(account, amount)
				ReportToWebhook(Config.Success, Config.WebhookTitle, "Successfully added $" .. amount .. " to " .. xPlayer.getName() .. "'s account: " .. account, Config.WebhookFooter)
			else
				ReportToWebhook(Config.Error, Config.WebhookTitle, "Invalid Account", Config.WebhookFooter)
			end
		else
			ReportToWebhook(Config.Error, Config.WebhookTitle, "Invalid Amount", Config.WebhookFooter)
		end
	end
end)