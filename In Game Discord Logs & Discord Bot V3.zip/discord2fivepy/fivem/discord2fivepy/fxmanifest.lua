fx_version 'cerulean'
games {'gta5'}

author 'Melktert'
description 'Discord2FivePY'
version '1.0.0'

server_scripts {
	'server/server.lua',
	'config.lua'
}